requested_topping = 'mushrooms'

if requested_topping != 'anchovies':
    print("Hold the anchovies!")