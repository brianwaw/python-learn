alien_0 = {'color': 'green'}
print(alien_0['color'])