user_0 = {
    'username': 'efermi',
    'first': 'enrico',
    'last': 'fermi',
    }
