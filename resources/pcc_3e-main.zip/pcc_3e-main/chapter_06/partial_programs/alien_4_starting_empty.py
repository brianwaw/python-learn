alien_0 = {}

alien_0['color'] = 'green'
alien_0['points'] = 5

print(alien_0)