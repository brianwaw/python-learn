name = "ada lovelace"
print(name.title())