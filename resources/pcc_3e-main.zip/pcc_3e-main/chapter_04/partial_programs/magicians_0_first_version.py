magicians = ['alice', 'david', 'carolina']
for magician in magicians:
    print(magician)