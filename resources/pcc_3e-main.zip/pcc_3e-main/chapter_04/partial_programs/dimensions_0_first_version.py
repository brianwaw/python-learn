dimensions = (200, 50)
print(dimensions[0])
print(dimensions[1])